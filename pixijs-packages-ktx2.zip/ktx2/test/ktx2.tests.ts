// import { Assets } from '@pixi/assets';
// import { loadKTX2 } from '../src/loader';
// import { TranscoderWorker } from '../src/TranscoderWorker';

// import type { Texture } from '@pixi/core';

describe('KTX2 loading', () =>
{
    // // CRASHES JEST - ELECTRON
    // it.skip('should load a a KTX2 image', async () =>
    // {
    //     await TranscoderWorker.loadTranscoder(
    //         '../assets/basis_transcoder.js',
    //         '../assets/basis_transcoder.wasm'
    //     );

    //     Assets.loader.parsers.push(loadKTX2);
    //     Assets.add('kodim20', './images/kodim20.ktx2');
    //     const texture: Texture = (await Assets.load(['kodim20']))[0];

    //     expect(texture.baseTexture.valid).toBe(true);
    //     expect(texture.width).toBe(1000);
    //     expect(texture.height).toBe(664);
    // });
});
