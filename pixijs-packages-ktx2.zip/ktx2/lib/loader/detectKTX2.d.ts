import type { FormatDetectionParser } from '@pixi/assets';
export declare const detectKTX2: FormatDetectionParser;
