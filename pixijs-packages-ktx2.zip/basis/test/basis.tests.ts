// import { Assets } from '@pixi/assets';
// import { loadBasis } from '../src/loader';
// import { TranscoderWorker } from '../src/TranscoderWorker';

// import type { Texture } from '@pixi/core';

describe('Basis loading', () =>
{
    // // CRASHES JEST - ELECTRON
    // it.skip('should load a a Basis image', async () =>
    // {
    //     await TranscoderWorker.loadTranscoder(
    //         '../assets/basis_transcoder.js',
    //         '../assets/basis_transcoder.wasm'
    //     );

    //     Assets.loader.parsers.push(loadBasis);
    //     Assets.add('kodim20', './images/kodim20.basis');
    //     const texture: Texture = (await Assets.load(['kodim20']))[0];

    //     expect(texture.baseTexture.valid).toBe(true);
    //     expect(texture.width).toBe(1000);
    //     expect(texture.height).toBe(664);
    // });
});
