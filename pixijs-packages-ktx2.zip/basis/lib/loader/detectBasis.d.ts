import type { FormatDetectionParser } from '@pixi/assets';
export declare const detectBasis: FormatDetectionParser;
